
#include<stdio.h>
void main()
{
    int num1;
    int num2;
    int num3;
    printf("Enter the number 1: ");
    scanf("%d",&num1);
    printf("Enter the number 2: ");
    scanf("%d",&num2);
    printf("Enter the number 3: ");
    scanf("%d",&num3);
  
  if (num1>num2)
     {
         printf("the number %d is great then number %d\n\n ",num1,num2);
     }                                                                                         
     
     
        else if (num1>num3)
           {
              printf("the number %d is great then number %d\n\n",num1,num3); 
           }
     else
     {
         printf("the number %d is smallest\n\n",num1);
     }
    
   if(num2>num1)
      {
          printf("the number %d is great then number %d\n\n",num2,num3);
          
      }
        else if (num2>num3)
           {
               printf("the number %d is great then number %d\n\n",num2,num3);
               
           }
      else
        {
            printf("the number %d is smallest\n\n",num2);
        }
          
    
          
          
          
          
          
      
    
    
    
     
}